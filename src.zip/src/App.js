import React from "react";
import "./App.css";
import Card from "./pages/card/Card";
import Navbar from "./pages/navbar/Navbar";
import Header from "./pages/header/Header";

export default function App() {
  return (
    <div className="container">
      <Navbar />
      <Header />
      <Card />
    </div>
  );
}
