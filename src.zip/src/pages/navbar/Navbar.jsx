import React from 'react'
import './Navbar.css'
import logo from '../../img/logo.svg'
import cart from '../../img/cart.svg'

export default function Navbar() {

    return (
        <div>
            <div className="navbar">
                <div className="navbar-left">
                    <img src={logo} alt='' />
                    <h1 className='navbar-title'>GREENSHOP</h1>
                </div>
                <div className="navbar-right">
                    <img className='navbar-img' src={cart} alt='' />
                    <button type='button' className='navbar-btn' data-toggle="modal" data-target="#exampleModal">Add</button>
                    <button className='navbar-btn'>Log in</button>
                </div>
            </div>
        </div>
    )
}
