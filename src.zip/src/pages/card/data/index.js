import img from "../../../img/image 1.svg";
export const data = [
  {
    name: "Barberton Daisy",
    category: "flowers",
    description: "Lorem ipsum color is and,Lorem ipsum color is and,Lorem ipsum color is and",
    price: "$119.00",
    img: img,
  },
  {
    name: "Angel Wing Begonia",
    category: "flowers",
    description: "Lorem ipsum color is and",
    price: "$169.00",
    img: img,
  },
  {
    name: "African Violet",
    category: "flowers",
    description: "Lorem ipsum color is and",
    price: "$199.00",
    img: img,
  },
  {
    name: "Blushing Bromeliad",
    category: "flowers",
    description: "Lorem ipsum color is and",
    price: "$139.00",
    img: img,
  },
];
