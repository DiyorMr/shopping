import React, { useEffect, useState } from 'react'
import './Card.css'




export default function Card() {
    const [data, setData] = useState([])
    const [app, setApp] = useState([])
    const [activeBtn, setActiveBtn] = useState('all')
    const [loader, setLoader] = useState(false)

    useEffect(() => {
        setLoader(true)
        fetch('https://fakestoreapi.com/products')
            .then(res => res.json())
            .then(json => setData(json))
            .finally(() => setLoader(false))

        fetch('https://fakestoreapi.com/products/categories')
            .then(res => res.json())
            .then(json => setApp(['all', ...json]))
    }, [])

    const sortProduct = (item) => {
        setLoader(true)
        setActiveBtn(item)
        if (item === 'all') {
            fetch('https://fakestoreapi.com/products')
                .then(res => res.json())
                .then(json => setData(json))
                .finally(() => setLoader(false))

        } else {
            fetch(`https://fakestoreapi.com/products/category/${item}`)
                .then(res => res.json())
                .then(json => setData(json))
                .finally(() => setLoader(false))
        }
    }

    return (
        <div>
            <div className="box-apps">
                <ul>{app.map((item, index) =>
                    <li className={activeBtn === item ? 'active' : ''} onClick={() => sortProduct(item)}>
                        {item}
                    </li>)}
                </ul>
            </div>

            < div className="box-title">
                {
                    loader ?
                        <div class="text-center w-100">
                            <div class="spinner-border" role="status">
                                <span class="sr-only"></span>
                            </div>
                        </div> :
                        <div className="flow">
                            {data.map((item, index) =>
                                <div className="flow-col">
                                    <div className="flowers">
                                        <img className='img' src={item.image} alt='' />
                                    </div>
                                    <div className="p-3 bg-white">
                                        <h4 className='category'>{item?.category}</h4>
                                        <h4 className='flower-name'>{item.title}</h4>
                                        <h1 className='title'>{item.description}</h1>
                                        <div className="d-flex align-items-center justify-content-between mt-4 bg-white" >
                                            <p className='price mb-0'>{item.price}$</p>
                                            <button className='flow-btn'>Add</button>
                                        </div>
                                    </div>

                                </div>
                            )}
                        </div>
                }
            </div>
        </div >
    )
}
